<footer >

    <i class="bi bi-linkedin float-end img-thumbnail d-none d-md-block"   ></i>
    <i class="bi bi-twitter float-end img-thumbnail d-none d-md-block"   ></i>
    <i class="bi bi-pinterest float-end img-thumbnail d-none d-md-block"  ></i>


    <p class="clearfix pb-3  text-muted text-center">&copy;Afdeling software development Tinwerf 10, 2544 ED Den Haag.</p>
</footer>
